package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactUsPage {
    WebDriver driver;

    @FindBy(id = "ContactUsFrm_first_name")
    WebElement firstName;

    @FindBy(id = "ContactUsFrm_email")
    WebElement email;

    @FindBy(id = "ContactUsFrm_enquiry")
    WebElement enquiry;

    @FindBy(xpath = "//button[@title='Submit']")
    WebElement submitButton;

    @FindBy(css = ".alert-success")
    WebElement successMessage;

    public ContactUsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void fillContactForm(String name, String emailText, String message) {
        firstName.sendKeys(name);
        email.sendKeys(emailText);
        enquiry.sendKeys(message);
    }

    public void submitForm() {
        submitButton.click();
    }

    public boolean isSubmissionSuccessful() {
        return successMessage.isDisplayed();
    }
}
