package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FooterPage {
    WebDriver driver;

    @FindBy(linkText = "About Us")
    WebElement aboutUsLink;

    @FindBy(linkText = "Privacy Policy")
    WebElement privacyPolicyLink;

    @FindBy(linkText = "Contact Us")
    WebElement contactUsLink;

    public FooterPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickAboutUs() {
        aboutUsLink.click();
    }

    public void clickPrivacyPolicy() {
        privacyPolicyLink.click();
    }

    public void clickContactUs() {
        contactUsLink.click();
    }

    public boolean isPageTitleCorrect(String expectedTitle) {
        return driver.getTitle().contains(expectedTitle);
    }
}
