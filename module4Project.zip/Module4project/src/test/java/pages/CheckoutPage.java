package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckoutPage {
    WebDriver driver;

    @FindBy(id = "checkout_btn")
    WebElement confirmOrderButton;

    @FindBy(xpath = "//h1[contains(text(),'Your Order Has Been Processed!')]")
    WebElement confirmationMessage;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void confirmOrder() {
        confirmOrderButton.click();
    }

    public boolean isOrderConfirmed() {
        return confirmationMessage.isDisplayed();
    }
}
