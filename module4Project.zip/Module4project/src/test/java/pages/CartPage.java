package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPage {
    WebDriver driver;

    @FindBy(xpath = "//a[@id='cart_checkout1']")
    WebElement checkoutButton;

    @FindBy(xpath = "//div[@class='contentpanel']")
    WebElement cartContent;

    public CartPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean isCartNotEmpty() {
        return cartContent.getText().contains("Item(s)");
    }

    public void clickCheckout() {
        checkoutButton.click();
    }
}
