package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchPage {
    WebDriver driver;

    public SearchPage(WebDriver driver) {
        this.driver = driver;
    }

    public void searchProduct(String productName) {
        driver.findElement(By.name("search")).sendKeys(productName);
        driver.findElement(By.cssSelector(".button-in-search")).click();
    }

    public boolean isSearchResultDisplayed(String productName) {
        return driver.getPageSource().contains(productName);
    }
}
