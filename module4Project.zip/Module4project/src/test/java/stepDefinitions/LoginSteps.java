package stepDefinitions;

import base.BaseTest;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import org.junit.Assert;
import pages.HomePage;
import pages.LoginPage;
import utils.ExtentReportManager;
import com.aventstack.extentreports.*;

public class LoginSteps extends BaseTest {
    HomePage homePage;
    LoginPage loginPage;
    ExtentReports extent;
    ExtentTest test;

    @Before
    public void setUp() {
        extent = ExtentReportManager.getReportInstance();
        test = extent.createTest("Login Test");
        initializeBrowser();
    }

    @After
    public void tearDown() {
        extent.flush();
        tearDown();
    }

    @Given("User is on the login page")
    public void user_is_on_login_page() {
        homePage = new HomePage(driver);
        homePage.clickLoginLink();
        test.info("Navigated to login page.");
    }

    @When("User enters valid credentials")
    public void user_enters_valid_credentials() {
        loginPage = new LoginPage(driver);
        loginPage.enterUsername("testuser");
        loginPage.enterPassword("testpass");
        test.info("Entered credentials.");
    }

    @And("Clicks the login button")
    public void clicks_login_button() {
        loginPage.clickLoginButton();
        test.info("Clicked login button.");
    }

    @Then("User should be navigated to the account page")
    public void user_should_be_navigated_to_account_page() {
        Assert.assertTrue(loginPage.isLoginSuccessful());
        test.pass("Login successful.");
    }
}
